# Expensy — Project Reference for Claude
 
> **Purpose:** This file gives a complete picture of the Expensy Flutter app so a new Claude chat can pick up work immediately without re-reading every source file.
> **Last synced with code:** v1.0.5+6
 
---
 
## 1. Project Identity
 
| Field | Value |
|---|---|
| Package name | `com.ma.expensy` |
| Flutter package | `expensy` |
| Version | `1.0.5+6` |
| Dart SDK | `>=3.3.0 <4.0.0` |
| Description | Fully offline, local-first personal finance tracker |
| Platform | Android only |
| GitHub | `https://github.com/mina-android/Expensy` |
| Developer | `https://github.com/mina-android` |
 
---
 
## 2. Architecture
 
```
lib/
├── main.dart                    # Entry point — wrapped in DynamicColorBuilder for Material You;
│                                 #   awaits NotificationService.initialize() then provider.load()
│                                 #   before runApp(); no loading screen
├── models/
│   └── models.dart              # All data classes (9 models)
├── database/
│   └── db_helper.dart           # SQLite v9 — all CRUD + backup import/export + _normaliseBackup
├── providers/
│   └── app_provider.dart        # AppProvider (ChangeNotifier) + AppSettings
├── services/
│   ├── exchange_rate_service.dart  # Fetch/cache/convert daily exchange rates + gold price (XAU)
│   └── notification_service.dart   # Schedule/cancel recurring-payment + lent/borrowed reminders
├── theme/
│   └── app_theme.dart           # buildTheme() (+ Material You + fonts), ExpensyRoute,
│                                 #   resolveThemeMode(), kSeedColours, kFonts, kCurrencies,
│                                 #   formatAmount()
├── widgets/
│   └── shared_widgets.dart      # Reusable UI components + kCategoryIconOptions icon catalogue
└── screens/ (20 screens)
    ├── main_shell.dart           # IndexedStack bottom nav (6 tabs)
    ├── home_screen.dart
    ├── accounts_screen.dart
    ├── add_transaction_screen.dart
    ├── transactions_screen.dart
    ├── recurring_screen.dart
    ├── transfer_screen.dart
    ├── budget_screen.dart        # NEW v1.0.5 — bottom-nav tab
    ├── more_screen.dart
    ├── statistics_screen.dart
    ├── insights_screen.dart      # NEW v1.0.5 — More tab
    ├── currency_converter_screen.dart  # NEW v1.0.5 — More tab
    ├── categories_screen.dart
    ├── wishlist_screen.dart
    ├── lended_screen.dart
    ├── assets_screen.dart        # product/asset tracker
    ├── export_screen.dart
    ├── backup_screen.dart
    ├── settings_screen.dart
    └── onboarding_screen.dart
```
 
**State management:** `provider` package. A single `AppProvider` extends `ChangeNotifier` and holds all app data in memory. Every screen uses `context.watch<AppProvider>()` to rebuild on changes, and `context.read<AppProvider>()` inside callbacks/submit methods.
 
**Navigation:** Bottom `NavigationBar` with **6 tabs** (Home, Transactions, Recurring, Accounts, **Budgets**, More) using an `IndexedStack` — no page transitions between tabs (`animationDuration: 120ms` on the nav bar itself). Sub-screens (Statistics, Insights, Currency Converter, Settings, Export, etc.) are pushed from the More tab using `ExpensyRoute` (see §8), never raw `MaterialPageRoute`.
 
**Startup:** `main()` is `async` and `await`s `provider.load()` before calling `runApp()`. This means the native `LaunchTheme` window background stays visible during the DB load and Flutter draws the real app as its very first frame — no intermediate loading screen exists. `MyApp.build()` wraps everything in a `DynamicColorBuilder` to source the Material You palette on Android 12+ (see §8).
 
---
 
## 3. Dependencies (`pubspec.yaml`)
 
```yaml
sqflite: ^2.3.3+1          # SQLite — MUST import with: hide Transaction
path: ^1.9.0
path_provider: ^2.1.4
fl_chart: ^0.68.0           # Bar/pie/line charts in Statistics + Insights
intl: ^0.19.0
uuid: ^4.5.0                # v4 UUIDs for all entity IDs
file_picker: ^8.1.2         # Save/load files (backup JSON, export XLSX)
provider: ^6.1.2
shared_preferences: ^2.3.2  # Stores AppSettings JSON + exchange rate cache
excel: ^4.0.6               # Excel export — MUST import with: hide Border
http: ^1.2.0                # Exchange rate API calls + gold price fetch
url_launcher: ^6.3.0        # Opens GitHub / Developer links from Settings → About
flutter_local_notifications: ^18.0.0  # Recurring + lent/borrowed reminders
timezone: ^0.9.4            # TZDateTime for zonedSchedule
google_fonts: ^6.2.1        # NEW v1.0.5 — 9 selectable app fonts
dynamic_color: ^1.7.0       # NEW v1.0.5 — Material You wallpaper colour extraction
cupertino_icons: ^1.0.8
```
 
**Critical import rules:**
```dart
import 'package:sqflite/sqflite.dart' hide Transaction;  // sqflite exports Transaction too
import 'package:excel/excel.dart' hide Border;            // excel exports Border too
```
 
**Do NOT add `flutter_timezone`** — it has a Kotlin 2.1.0 incompatibility. Timezone offset is computed via `DateTime.now().timeZoneOffset` instead (see `NotificationService._toUtcTZDate()`).
 
---
 
## 4. Data Models (`lib/models/models.dart`)
 
All models have `toMap()` / `static fromMap()` for SQLite, and `copyWith()` (`Budget` and `RecurringHistoryEntry` are immutable — `Budget` has `copyWith()`, `RecurringHistoryEntry` does not need one).
 
### `Account`
```
id, name, type, balance, currency, colorValue, excludeFromTotal, createdAt,
goldKarat, goldGrams
type:    bank | cash | savings | credit | wallet | gold
```
- `excludeFromTotal: true` → account is excluded from **home screen** total balance only; the Accounts tab AppBar always shows `totalBalanceAll` (all accounts)
- `balance` is the running balance (updated on every transaction)
- `currency` may differ from `settings.currency` — multi-currency is supported
- **Gold accounts** (`type == 'gold'`): `goldKarat` (int: 24/22/21/18/14/10/9) and `goldGrams` (double) store the physical holding. `balance` is auto-recalculated from XAU rates on every rate refresh. `isGold` getter returns `type == 'gold'`. Gold accounts are **excluded** from transaction pickers, transfer pickers, recurring pickers, and lended pickers — their balance is always synthetic.
### `AppCategory`
```
id, name, type, colorValue, iconCodePoint
type:          income | expense
iconCodePoint: 1-based index into kCategoryIconOptions (shared_widgets.dart); 0 = "Auto"
               (pick an icon heuristically from the category name)
```
> **Renamed from `Category`** to avoid conflict with `flutter/foundation.dart`
 
- **NEW v1.0.5:** `iconCodePoint` despite its name does **not** store a raw `IconData.codePoint`. It stores a **1-based index** into the constant `kCategoryIconOptions` list. `0` means "Auto" — `CategoryDot` falls back to `_catIcon(category.name)`, a small heuristic matcher. This indirection exists so the app never calls `IconData(variable, fontFamily: ...)` at runtime, which would break Flutter's release-mode icon tree-shaking. Always resolve via `kCategoryIconOptions[iconCodePoint - 1].icon`.
### `AppTransaction`
```
id, type, amount, description, accountId, categoryId, date, note, currency
type:     income | expense
currency: the currency the amount was entered in; empty string = use the account's currency
```
> **Renamed from `Transaction`** to avoid conflict with `sqflite`
 
- `currency` is stored in the DB column `currency TEXT NOT NULL DEFAULT ''`.
- When `currency` is empty the amount is treated as being in the account's own currency.
- When displaying, use `t.currency.isNotEmpty ? t.currency : account.currency` as the display currency.
- The account balance delta is always computed in the account's currency. If `t.currency` differs, the provider converts via exchange rates before applying the delta.
### `RecurringPayment`
```
id, name, accountId, categoryId, amount, paymentType,
freqVal, freqUnit, startDate, nextDate, endDate,
paidPayments, reminderEnabled, reminderTime, earlyReminderEnabled, notes
paymentType:  expense | income
freqUnit:     days | weeks | months | years
endDate:      null = ongoing
reminderTime: 'HH:mm' string, e.g. '09:00' — time of day for the notification
```
Computed getters: `totalPayments`, `remainingPayments`, `remainingAmount`, `totalAmount`, `frequencyLabel`, `calcNextDate()`
 
**Important:** whenever constructing a new `RecurringPayment` in `markRecurringPaid` or `skipNextRecurring`, always pass `reminderTime: r.reminderTime` — it is NOT in `copyWith()` so it must be threaded manually.
 
### `WishlistItem`
```
id, name, targetPrice, priority, isPurchased, notes, createdAt
priority: low | medium | high
```
 
### `LendedMoney`
```
id, personName, amount, type, accountId, isSettled, date, dueDate, notes,
reminderEnabled, reminderTime
type:            lent | borrowed
accountId:       nullable (lend not linked to an account)
reminderEnabled: NEW v1.0.5 — fires a notification on dueDate at reminderTime
reminderTime:    'HH:mm' string, e.g. '09:00'
```
- A reminder can only be enabled when `dueDate != null`; the UI enforces this (see `lended_screen.dart` §10).
### `AssetItem`
```
id, name, value, currency, notes, createdAt
```
- Tracks physical or financial assets (products, property, investments, etc.)
- `currency` is the currency of the asset's value — may differ from `settings.currency`
- `totalAssetsValue` in `AppProvider` converts all assets to the main currency using exchange rates
### `Budget` — **NEW v1.0.5**
```
id, categoryId, amount, period, createdAt   (all final — immutable, has copyWith())
period: 'monthly' | 'weekly'
```
- One budget per category is the intended UX (`budgetForCategory()` returns the first match), though the schema does not enforce uniqueness
- See §6 for `budgetSpent()` / `budgetRemaining()` / `budgetProgress()` / `budgetExceeded()`
### `RecurringHistoryEntry` — **NEW v1.0.5**
```
id, recurringId, action, date, amount, currency   (all final — immutable, no copyWith())
action: 'paid' | 'skipped'
```
- One row is inserted every time `markRecurringPaid()` or `skipNextRecurring()` runs
- Deleted in bulk via `DBHelper.deleteRecurringHistoryFor(recurringId)` when the parent recurring payment is deleted
---
 
## 5. Database (`lib/database/db_helper.dart`)
 
- **Engine:** SQLite via `sqflite`
- **File:** `expensy.db` in `getDatabasesPath()`
- **Version:** 9
- **Migrations (`_onUpgrade`):**
  - v1 → v2: `ALTER TABLE accounts ADD COLUMN exclude_from_total INTEGER NOT NULL DEFAULT 0`
  - v1 → v2: `ALTER TABLE recurring_payments ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'expense'`
  - v2 → v3: `ALTER TABLE recurring_payments ADD COLUMN reminder_time TEXT NOT NULL DEFAULT '09:00'`
  - v3 → v4: `ALTER TABLE transactions ADD COLUMN currency TEXT NOT NULL DEFAULT ''`
  - v4 → v5: `CREATE TABLE IF NOT EXISTS assets (...)`
  - v5 → v6: `ALTER TABLE accounts ADD COLUMN gold_karat INTEGER` and `ADD COLUMN gold_grams REAL`
  - v6 → v7: `ALTER TABLE recurring_payments ADD COLUMN early_reminder_enabled INTEGER NOT NULL DEFAULT 0`
  - **v7 → v8** *(new in 1.0.5)*: `CREATE TABLE IF NOT EXISTS budgets (...)`, `CREATE TABLE IF NOT EXISTS recurring_history (...)`, `CREATE INDEX IF NOT EXISTS idx_rh_recurring_id ON recurring_history(recurring_id)`
  - **v8 → v9** *(new in 1.0.5)*: `ALTER TABLE categories ADD COLUMN icon_code_point INTEGER NOT NULL DEFAULT 0`, `ALTER TABLE lended_money ADD COLUMN reminder_enabled INTEGER NOT NULL DEFAULT 0`, `ADD COLUMN reminder_time TEXT NOT NULL DEFAULT '09:00'`
- Migration guards use `if (oldV < N)` so upgrading from any old version applies all steps correctly.
### Tables & Schema
 
```sql
accounts(id, name, type, balance, currency, color_value, exclude_from_total, created_at,
         gold_karat INTEGER, gold_grams REAL)
categories(id, name, type, color_value, icon_code_point INTEGER NOT NULL DEFAULT 0)
transactions(id, type, amount, description, account_id, category_id, date, note, currency)
recurring_payments(id, name, account_id, category_id, amount, payment_type,
                   freq_val, freq_unit, start_date, next_date, end_date,
                   paid_payments, reminder_enabled, reminder_time,
                   early_reminder_enabled, notes)
wishlist(id, name, target_price, priority, is_purchased, notes, created_at)
lended_money(id, person_name, amount, type, account_id, is_settled, date, due_date, notes,
             reminder_enabled INTEGER NOT NULL DEFAULT 0,
             reminder_time TEXT NOT NULL DEFAULT '09:00')
assets(id, name, value, currency, notes, created_at)
budgets(id, category_id, amount, period TEXT NOT NULL DEFAULT 'monthly', created_at)        -- NEW
recurring_history(id, recurring_id, action, date, amount, currency)                          -- NEW
  -- idx_rh_recurring_id index on recurring_history(recurring_id)
```
 
### Default Categories (seeded on first install)
 
| ID | Name | Type |
|---|---|---|
| `food_exp` | Food & Dining | expense |
| `transport` | Transport | expense |
| `shopping` | Shopping | expense |
| `bills` | Bills & Utilities | expense |
| `health` | Health | expense |
| `entertainment` | Entertainment | expense |
| `education` | Education | expense |
| `other_exp` | Other | expense |
| `salary` | Salary | income |
| `freelance` | Freelance | income |
| `business` | Business | income |
| `investment` | Investment | income |
| `gift` | Gift | income |
 
All default categories seed with `icon_code_point = 0` (Auto) — they resolve through the name-based heuristic in `CategoryDot`.
 
### Backup & Restore
 
`exportAll()` returns a `Map<String, dynamic>` with keys:
`accounts`, `categories`, `transactions`, `recurring_payments`, `wishlist`, `lended_money`, `assets`, **`budgets`**, **`recurring_history`**, `version`
 
`importAll(data)` calls `_normaliseBackup(data)` first, then deletes + re-inserts all 9 tables inside a single DB transaction. After restore, `AppProvider.restoreBackup()` calls `NotificationService().rescheduleAll(recurring, settings.currency, lended: lended)` to re-register every recurring **and** lent/borrowed reminder, and clears the in-memory recurring-history cache.
 
**`_normaliseBackup(data)`** — called inside `importAll` before any DB writes. Patches every row of every table using `putIfAbsent` so old backup files (any version) are safe to restore:
 
| Table | Fields patched if absent |
|---|---|
| `accounts` | `exclude_from_total → 0`, `currency → 'EGP'`, `gold_karat → null`, `gold_grams → null` |
| `transactions` | `note → ''`, `currency → ''` |
| `recurring_payments` | `payment_type → 'expense'`, `reminder_enabled → 0`, `reminder_time → '09:00'`, `early_reminder_enabled → 0`, `notes → ''`, `paid_payments → 0`; also normalises singular freq_unit strings (day→days, etc.) |
| `wishlist` | `is_purchased → 0`, `notes → ''`, `priority → 'low'` |
| `lended_money` | `is_settled → 0`, `notes → ''`, `due_date → null`, `account_id → null`, **`reminder_enabled → 0`**, **`reminder_time → '09:00'`** *(new v9)* |
| `assets` | entire key inserted as `[]` if missing; `currency → 'EGP'`, `notes → ''` per row |
| `categories` | **`icon_code_point → 0`** per row *(new v9)* |
| `budgets` | entire key inserted as `[]` if missing; `period → 'monthly'` per row *(new v8)* |
| `recurring_history` | entire key inserted as `[]` if missing *(new v8)* |
 
Also stamps `data['_originalVersion']` with the source backup version for the UI to display.
 
> **Known gap:** `backup_screen.dart`'s "what's included" live-count list was **not** updated in v1.0.5 — it still hardcodes 8 `_CountRow`s (Accounts, Transactions, Recurring, Wishlist, Lent & Borrowed, Assets, Categories, Settings) and does not show a row for Budgets or Recurring History, even though both are fully included in the exported JSON and fully restored. Fixing this is a good small follow-up task.
 
---
 
## 6. State & Business Logic (`lib/providers/app_provider.dart`)
 
### `AppSettings` (persisted via `SharedPreferences` as JSON key `'settings'`)
```dart
currency:       String  // e.g. 'EGP'
themeSeed:      String  // key into kSeedColours, e.g. 'violet'
themeMode:      String  // 'system' | 'light' | 'dark'  — 'amoled' is NOT a valid value any more
weekStart:      String  // 'monday' | 'sunday'
hideBalance:    bool
userName:       String
onboarded:      bool
appFont:        String  // NEW — key into kFonts, e.g. 'inter'; 'default' = system/Roboto
amoledSurfaces: bool    // NEW — pure-black surfaces when dark; decoupled from themeMode
```
 
**`AppSettings.fromJson` migrations** (handles all old backup/preference formats):
- `pitch_black` seed → `midnight` seed
- Any unrecognised `themeSeed` → `'violet'`
- Legacy `darkMode: bool` field (pre-v1.0.3) → correct `themeMode` string
- **Legacy `themeMode: 'amoled'`** *(pre-v1.0.5)* → migrated to `themeMode: 'dark'` **+** `amoledSurfaces: true`
- Any unrecognised `themeMode` value → `'dark'`
- Any unrecognised `appFont` value → `'default'`
- Valid seeds: the 29 keys in `kSeedColours`; valid modes: `system | light | dark`; valid fonts: the 10 keys in `kFonts`
### `AppProvider` — in-memory lists
```dart
accounts:     List<Account>
categories:   List<AppCategory>
transactions: List<AppTransaction>
recurring:    List<RecurringPayment>
wishlist:     List<WishlistItem>
lended:       List<LendedMoney>
assets:       List<AssetItem>
budgets:      List<Budget>                                    // NEW
settings:     AppSettings
 
// Exchange rates
exchangeRates:     Map<String, double>  // rates relative to USD; empty until loaded
ratesLoaded:       bool                 // true once cache lookup completes
ratesFetching:     bool                 // true while a network call is in flight
ratesLastFetched:  DateTime?            // timestamp of last successful fetch
 
// Recurring history (lazy cache, NEW)
_historyCache: Map<String, List<RecurringHistoryEntry>>   // keyed by recurringId
```
 
### Key computed properties & helpers
```dart
bool get loaded                           // always true — load() is awaited before runApp()
 
// Balance totals
double get totalBalance                   // excludes accounts with excludeFromTotal=true; used on Home screen
double get totalBalanceAll                // includes ALL accounts regardless of excludeFromTotal; used in Accounts tab AppBar
 
// Exchange rates & gold
double get totalAssetsValue               // currency-aware: converts each asset to settings.currency
double convertToMain(double, String)      // convert any amount to the main currency
double? convertBetween(double, String from, String to)  // convert between any two currencies; null when rates unavailable
bool canShowConverted(Account)            // true when rates are ready for this account's currency
bool get goldRatesAvailable               // true when XAU is present in exchangeRates and > 0
double? goldPricePerGram(String currency) // spot price per gram of 24k gold in [currency]; null if XAU unavailable
double? computeGoldValue({grams, karat, currency}) // computes value of a gold holding; null if XAU unavailable
Future<void> refreshRates()               // force a fresh network fetch
 
// Budgets (NEW)
Budget?  budgetForCategory(String categoryId)
double   budgetSpent(Budget budget)       // sums this-period expenses for the budget's category, converted to main currency
double   budgetRemaining(Budget b)        // (amount - spent).clamp(0, ∞)
double   budgetProgress(Budget b)         // (spent / amount).clamp(0, 1)
bool     budgetExceeded(Budget b)         // spent > amount
 
// Recurring history (NEW)
Future<List<RecurringHistoryEntry>> getHistoryFor(String recurringId)  // cached after first load
 
// Lookups
Account?     accountById(String id)
AppCategory? categoryById(String id)
String newId()                            // generates a v4 UUID
```
 
### `totalBalance` vs `totalBalanceAll`
```dart
// Home screen — respects excludeFromTotal
double get totalBalance => accounts
    .where((a) => !a.excludeFromTotal)
    .fold(0.0, (sum, a) { ... });
 
// Accounts tab AppBar — always shows everything
double get totalBalanceAll => accounts
    .fold(0.0, (sum, a) { ... });
```
 
### Gold account balance lifecycle
- Created: `balance` = `computeGoldValue(grams, karat, currency)` at time of creation; 0 if gold price unavailable at that moment (user sees error and can't save).
- Updated: `_refreshGoldBalances()` is called at the end of every `_loadRates()` (both cache and network). It recomputes `balance` for every gold account using current XAU rates and saves to DB.
- `_updateAccountBalance()` silently skips gold accounts — their balance is never touched by transactions.
- Gold accounts are filtered out (`!a.isGold`) from all picker widgets: `AccountCardPicker` in Add Transaction, Transfer FROM/TO, Recurring, and Lended screens.
### Balance tracking rules (non-gold accounts)
- `addTransaction`: converts the transaction amount to the account's currency if `t.currency` differs, then applies `±convertedAmount` to `account.balance`
- `deleteTransaction`: reverses the same converted delta
- `updateTransaction(updated, original)`: reverses original effect (including its currency), applies new effect
- `addTransfer(fromId, toId, fromAmount, {toAmount, note})`: deducts `fromAmount` from source in its own currency; credits `toAmount` (or a converted equivalent) to destination in its currency. Creates two `AppTransaction` records tagged with their respective currencies; calls `DBHelper.insertTransaction` directly to avoid double balance update
- `addLended(lent)`: `-amount` from account; `addLended(borrowed)`: `+amount` to account
- `settleLended`: reverses the lend/borrow balance effect
### `_loadRates()` — **rewritten in v1.0.5** as explicit stale-while-revalidate
```dart
Future<void> _loadRates({bool forceNetwork = false}) async {
  if (forceNetwork) {
    // Blocking: forceRefresh() → ensure XAU present → set state → notifyListeners() → _refreshGoldBalances()
    return;
  }
  // 1. Serve cached rates immediately (ExchangeRateService.getCached()), ensure XAU present,
  //    set state, notifyListeners(), _refreshGoldBalances() — UI updates with stale-but-usable data.
  // 2. If the cache is stale (ExchangeRateService.isFresh() == false), set ratesFetching = true,
  //    notifyListeners(), then await forceRefresh() in the background, ensure XAU present,
  //    set state again, notifyListeners() a SECOND time, _refreshGoldBalances() again.
}
```
**Why this matters:** the pre-1.0.5 implementation called `ExchangeRateService.getRates()`, which itself kicked off a *fire-and-forget* background refresh and returned immediately — the freshly-fetched rates were cached but never pushed back into the provider, so the UI only ever saw them on the **next** `_loadRates()` call (i.e. next app launch). The fix moves the "is it stale, should I refetch" decision into `AppProvider`, which can `await` the refresh and call `notifyListeners()` a second time when it completes.
 
### Notification hooks in recurring methods
 
Every recurring provider method that changes state also updates `NotificationService`:
 
| Method | Notification action |
|---|---|
| `addRecurring(r)` | `scheduleReminder(r)` if `r.reminderEnabled` |
| `updateRecurring(r)` | `cancelReminder(r.id)` → `scheduleReminder(r)` if enabled |
| `deleteRecurring(id)` | `cancelReminder(id)` **+** `deleteRecurringHistoryFor(id)` **+** evict `_historyCache[id]` |
| `markRecurringPaid(r)` | `addTransaction()` → **`_recordHistory(r, 'paid')`** → `cancelReminder(r.id)` → `scheduleReminder(updated)` with new `nextDate` |
| `skipNextRecurring(r)` | **`_recordHistory(r, 'skipped')`** → `cancelReminder(r.id)` → `scheduleReminder(updated)` with new `nextDate` |
| `restoreBackup()` | `rescheduleAll(recurring, settings.currency, lended: lended)` + clears `_historyCache` |
 
### Notification hooks in lended methods — **NEW v1.0.5**
 
| Method | Notification action |
|---|---|
| `addLended(l)` | `scheduleLendedReminder(l, settings.currency)` if `l.reminderEnabled && l.dueDate != null` |
| `updateLended(updated, original)` | `cancelLendedReminder(original.id)` → `scheduleLendedReminder(updated, ...)` if `updated.reminderEnabled && updated.dueDate != null && !updated.isSettled` |
| `settleLended(l)` | `cancelLendedReminder(l.id)` — no reminder once settled |
| `deleteLended(id)` | `cancelLendedReminder(id)` |
 
### Recurring history helpers — **NEW v1.0.5**
```dart
Future<void> _recordHistory(RecurringPayment r, String action) async {
  // Builds a RecurringHistoryEntry (id, recurringId: r.id, action, date: now,
  // amount: r.amount, currency: accountById(r.accountId)?.currency ?? settings.currency),
  // inserts it, then evicts _historyCache[r.id] so the next getHistoryFor() reloads from DB.
}
 
Future<List<RecurringHistoryEntry>> getHistoryFor(String recurringId) async {
  // Returns _historyCache[recurringId] if present, else loads from DBHelper.getRecurringHistory()
  // and caches the result.
}
```
 
### Budget helpers — **NEW v1.0.5**
```dart
Future<void> addBudget(Budget b)
Future<void> updateBudget(Budget b)
Future<void> deleteBudget(String id)
 
Budget? budgetForCategory(String categoryId) =>
    budgets.where((b) => b.categoryId == categoryId).firstOrNull;
 
double budgetSpent(Budget budget) {
  // periodStart = first of the month (period == 'monthly')
  //            or start of the current week respecting settings.weekStart (period == 'weekly')
  // Sums all expense transactions for budget.categoryId with date >= periodStart,
  // converting each to the main currency via convertToMain().
}
 
double budgetRemaining(Budget b) => (b.amount - budgetSpent(b)).clamp(0.0, double.infinity);
double budgetProgress(Budget b)  => (budgetSpent(b) / b.amount).clamp(0.0, 1.0);
bool   budgetExceeded(Budget b)  => budgetSpent(b) > b.amount;
```
Weekly period start respects `settings.weekStart`: `offset = weekStart == 'monday' ? (now.weekday - 1) : (now.weekday % 7)`, then `periodStart = today - offset days`.
 
### `load()` boot sequence
```dart
Future<void> load() async {
  // 1. Load settings from SharedPreferences
  // 2. Load all DB tables (accounts, categories, transactions, recurring,
  //    wishlist, lended, assets, budgets)
  // 3. Set _loaded = true, notifyListeners()
  // 4. Fire _loadRates() non-blocking (stale-while-revalidate; see above)
}
```
`load()` is called and **awaited** in `main()` before `runApp()`. The `_loaded` flag remains but is always `true` by the time any widget builds — the `!app.loaded` guard and the `_LoadingScreen` widget no longer exist.
 
### Asset CRUD
```dart
Future<void> addAsset(AssetItem a)
Future<void> updateAsset(AssetItem a)
Future<void> deleteAsset(String id)
double get totalAssetsValue   // sum of all asset values converted to settings.currency
```
 
### `restoreBackup()` — return value
Returns `int` (was `bool`):
- `0` → user cancelled the file picker (show nothing)
- `≥ 1` → success; the value is the original backup's version number
- Throws `FormatException` with a human-readable message for invalid files (not a JSON object, or no recognisable Expensy keys — the known-keys set now includes `budgets` and `recurring_history`)
### All `_submit()` methods in sheets use `context.read<AppProvider>()`
Never `widget.app` (stale snapshot). This is important for bottom sheet state.
 
---
 
## 7. Services
 
### `ExchangeRateService` (`lib/services/exchange_rate_service.dart`)
 
Singleton. Fetches from `https://open.er-api.com/v6/latest/USD` (free, no API key, daily updates). All rates are relative to USD as pivot.
 
**XAU (gold) is NOT in the open.er-api.com free tier.** It is fetched separately from the fawaz currency API and injected into the rates map before caching:
- **Primary:** `https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/xau.min.json`
- **Fallback:** `https://latest.currency-api.pages.dev/v1/currencies/xau.min.json`
- Response: `{"date":"2026-05-26","xau":{"usd":4540.33,"egp":237110.38,...}}`
- XAU rate stored as `1 / xau["usd"]` (troy oz per 1 USD, matching the USD-pivot format)
- `_fetchGoldRate()` tries primary, falls back to fallback on any failure
```dart
Future<Map<String, double>> getRates()           // legacy/back-compat: returns cached rates only, no longer triggers an implicit background fetch
Future<Map<String, double>?> getCached()         // NEW v1.0.5 — returns cached rates without triggering anything
Future<bool> isFresh()                           // NEW v1.0.5 — true when cache exists and is < 24h old
Future<Map<String, double>?> forceRefresh()      // explicit network fetch (also re-fetches XAU)
Future<double?> fetchGoldRate()                  // public: fetch XAU rate independently
Future<void> patchCachedXau(double xauRate)      // inject XAU into cached rates without resetting TTL
Future<DateTime?> lastFetchedAt()                // timestamp of last successful fetch
double? convert(amount, from, to, rates)         // pivot through USD; null if rate missing
```
 
> **v1.0.5 change:** `getRates()` previously did the staleness check *and* fired an unawaited background refresh internally — the caller never saw the refreshed values. `AppProvider` now owns that orchestration explicitly via `getCached()` + `isFresh()` + `forceRefresh()` (see §6). Don't reintroduce implicit fetching inside `getRates()`.
 
Cache keys in `SharedPreferences`: `er_rates` (JSON map, always includes XAU after first fetch), `er_fetched_at` (ISO8601 timestamp). TTL = 24 hours.
 
### `NotificationService` (`lib/services/notification_service.dart`)
 
Singleton. Wraps `flutter_local_notifications`. **Do not use `flutter_timezone`** — timezone is handled via `DateTime.now().timeZoneOffset` in `_toUtcTZDate()`.
 
```dart
Future<void> initialize()                              // called once in main() before runApp
Future<bool> requestPermissions()                      // POST_NOTIFICATIONS + SCHEDULE_EXACT_ALARM
Future<bool> hasPermission()                           // check current permission state
 
// Recurring payments
Future<void> scheduleReminder(RecurringPayment, String mainCurrency)
Future<void> cancelReminder(String paymentId)
 
// Lent / Borrowed — NEW v1.0.5
Future<void> scheduleLendedReminder(LendedMoney, String mainCurrency)
Future<void> cancelLendedReminder(String lendedId)
 
// Combined reschedule (e.g. after backup restore) — signature changed in v1.0.5
Future<void> rescheduleAll(
  List<RecurringPayment> payments,
  String mainCurrency, {
  List<LendedMoney> lended = const [],
})
```
 
**Notification IDs:**
- Recurring: `paymentId.hashCode & 0x7FFFFFFF` — stable positive int across restarts.
- Lent/Borrowed *(NEW)*: `'lended_$lendedId'.hashCode & 0x7FFFFFFF` — the `'lended_'` prefix guarantees no collision with recurring-payment IDs even if the underlying UUIDs were ever to match.
**Channels:**
- `expensy_recurring` / "Recurring Payment Reminders" — `Importance.high`, vibration on, exact alarm.
- `expensy_lended` / "Lent & Borrowed Reminders" *(NEW v1.0.5)* — same `Importance.high` / exact-alarm treatment, kept on a separate channel so users can mute one without the other.
`scheduleLendedReminder()` no-ops when `!reminderEnabled || isSettled || dueDate == null`. Body text is `"$amount you lent to $personName is due today"` or the borrowed equivalent; title is `"💸 Due: $personName"` (lent) or `"💰 Due: $personName"` (borrowed).
 
---
 
## 8. Theme System (`lib/theme/app_theme.dart`)
 
### Theme modes
| `themeMode` value | Flutter `ThemeMode` | Effect |
|---|---|---|
| `'system'` | `ThemeMode.system` | Follows device; on Android 12+ also enables Material You (see below) |
| `'light'` | `ThemeMode.light` | Always light |
| `'dark'` | `ThemeMode.dark` | Always dark |
 
> **`'amoled'` is no longer a valid `themeMode` value.** AMOLED is now the independent `settings.amoledSurfaces` bool, applied on top of whichever mode is active (works with `system`'s dark branch and with `dark`; meaningless under `light` and hidden from the UI in that case). Old `themeMode: 'amoled'` values are migrated to `themeMode: 'dark'` + `amoledSurfaces: true` by `AppSettings.fromJson`.
 
### Material You / Dynamic Colour — **NEW v1.0.5**
```dart
ThemeData buildTheme({
  required String seed,
  required bool dark,
  bool amoled = false,
  String appFont = 'default',
  ColorScheme? dynamicScheme,   // NEW — pass the device-extracted palette here
})
```
- `main.dart` wraps `MaterialApp` in a `DynamicColorBuilder(builder: (lightDynamic, darkDynamic) {...})`.
- `usesDynamic = settings.themeMode == 'system'`. When true, `dynamicScheme` is passed through (`lightDynamic` / `darkDynamic`); otherwise `null`.
- Inside `buildTheme()`: if `dynamicScheme != null`, it's used as the base `ColorScheme` (with the AMOLED surface overrides applied via `.copyWith(...)` when `amoled` is true) **instead of** `ColorScheme.fromSeed(seed)`.
- On pre-Android-12 devices, `dynamicScheme` is `null` from the builder regardless of mode, so the app transparently falls back to the seed colour — no extra handling needed at call sites.
- The accent-seed picker in Settings is only meaningful when Material You is *not* active (i.e. `themeMode != 'system'`, or `'system'` on an older device).
### Fonts — **NEW v1.0.5**
```dart
const Map<String, String> kFonts = {
  'default':           'System Default',
  'plus_jakarta_sans': 'Plus Jakarta Sans',
  'dm_sans':           'DM Sans',
  'inter':              'Inter',
  'nunito_sans':       'Nunito Sans',
  'space_grotesk':     'Space Grotesk',
  'outfit':            'Outfit',
  'sora':              'Sora',
  'poppins':           'Poppins',
  'nunito':            'Nunito',
};
```
- `_applyFont(font, baseTextTheme)` switches on the key and calls the matching `GoogleFonts.*TextTheme(base)`; `'default'` returns `base` unchanged (system/Roboto).
- `buildTheme()` builds the base `TextTheme` from a brightness-only `ThemeData`, then applies the font via `_applyFont()` before constructing the final `ThemeData`.
### Page transitions — **NEW v1.0.5**
```dart
class ExpensyRoute<T> extends MaterialPageRoute<T> {
  ExpensyRoute({required super.builder, super.settings});
  @override Duration get transitionDuration => const Duration(milliseconds: 220);  // push
  @override Duration get reverseTransitionDuration => const Duration(milliseconds: 160);  // pop
}
```
- Paired with `_FadeUpTransitionBuilder` (set as the Android entry in the theme's `pageTransitionsTheme`): fade + 8px upward slide on push (`Curves.easeOutCubic`), fade out on pop (`Curves.easeIn`).
- **Use `ExpensyRoute` everywhere instead of `MaterialPageRoute`** for screen pushes — `home_screen.dart`, `onboarding_screen.dart`, `more_screen.dart`, and `transactions_screen.dart` were all migrated in v1.0.5; any new screen-to-screen navigation should follow suit.
- iOS keeps `CupertinoPageTransitionsBuilder` (irrelevant in practice — Android-only app, but kept for completeness/parity).
### 29 Seed Colours (`kSeedColours`) — unchanged since v1.0.3
violet, blue, green, rose, amber, teal, orange, indigo, cyan, pink, lime, deep_purple, crimson, midnight, forest, mint, olive, sage, sky, navy, cobalt, ocean, coral, gold, slate, magenta, turquoise, brown, lavender
 
> `pitch_black` is **not** a valid seed — old backups using it are migrated to `midnight` by `AppSettings.fromJson`.
 
### Currency utility
```dart
CurrencyInfo currencyInfo(String code)    // looks up by code
String formatAmount(double amount, String code)
// Shows: '-EGP 42.00' for negative, 'EGP 42.00' for positive
```
**61 currencies** defined in `kCurrencies` (Global, MENA, Africa, Asia, Europe) — includes GEL (Georgian Lari, ₾) and, new in v1.0.5, **AUD (Australian Dollar)**.
 
> Note: the codebase's actual `kCurrencies` list has always had ~60 entries even though older docs (and this file, pre-sync) claimed 64–65. Trust the literal count in `app_theme.dart` over any prose description, including this one, if they ever diverge again.
 
---
 
## 9. Shared Widgets (`lib/widgets/shared_widgets.dart`)
 
| Widget / Function | Purpose |
|---|---|
| `EmptyState` | Centered icon + message for empty lists |
| `SectionHeader` | Uppercase label with spacing |
| `CategoryDot` | Coloured icon container representing a category — resolves the icon via `category.iconCodePoint` (1-based index into `kCategoryIconOptions`, or the name heuristic when 0) |
| `AccountTypeIcon` | Icon for bank/cash/savings/credit/wallet/**gold** |
| `LinearProgressCard` | Thin progress bar (used in recurring payments) |
| `AccountCardPicker` | Horizontal scrollable card row for selecting an account; `allowNone: true` adds a "None" card. Always filter gold accounts before passing: `app.accounts.where((a) => !a.isGold).toList()` |
| `CategoryChipPicker` | Wrap of coloured chips for selecting a category |
| `CategoryIconOption` *(NEW)* | `{ IconData icon; String label; }` — one entry in the icon catalogue below |
| `kCategoryIconOptions` *(NEW)* | `const List<CategoryIconOption>`, **57 entries** grouped into Finance, Food & Home, Transport, Shopping, Health, Entertainment & Education, Work & Business, Misc. **Never** build an `IconData` from a stored int at runtime — always index into this constant list, or tree-shaking breaks in release builds |
| `showDeleteConfirm(context, name)` | `Future<bool>` confirmation dialog |
| `showCurrencyPicker(context, current:)` | `Future<String?>` searchable currency dialog |
 
Most `AnimatedContainer` tap-feedback durations across pickers were shortened in v1.0.5 for snappier feel (typically `140ms → 100ms`, colour swatches `80ms → 60ms`) — keep new pill/chip/swatch widgets in that ~100ms range for visual consistency.
 
---
 
## 10. Screen-by-Screen Reference
 
### `main_shell.dart`
- `IndexedStack` with **6 children**: Home, Transactions, Recurring, Accounts, **Budgets**, More
- Bottom `NavigationBar`: Home · Transactions · Recurring · Accounts · **Budgets** (`Icons.pie_chart_outline_rounded` / `pie_chart_rounded`) · More — `animationDuration: 120ms`
### `home_screen.dart`
- Compact header with greeting + `totalBalance` (respects `excludeFromTotal`)
- Icons: visibility toggle + transfer button
- Month summary chips (Income / Expenses / Net)
- Horizontal account cards scroll — gold accounts show `"Xk · Y.YY g"` sub-label instead of converted amount
- 5 most recent transactions list
- FAB → `AddTransactionScreen`; navigation uses `ExpensyRoute`
### `accounts_screen.dart`
- AppBar shows `totalBalanceAll` (ALL accounts, including excluded) + `↺` sync button when any account uses a different currency
- `_RatesBanner` thin strip below AppBar: shows fetch status, last-updated timestamp, or offline warning
- `_AccountCard` uses `context.watch<AppProvider>()` so it rebuilds when rates arrive
- Gold accounts show a dedicated stats row: **Value / Karat / Weight / Per gram** instead of Income/Expense/Txs
- Gold accounts show a `"Xk · Y.YY g"` pill badge in the header row
- `_AccountSheet` bottom sheet for add/edit:
  - Type selector includes **Gold** (dark-gold colour, `Icons.diamond_outlined`)
  - Gold type shows: karat picker (24/22/21/18/14/10/9 pill cards with purity %), weight field (grams)
  - `_GoldPreviewCard`: live value preview; only shown when `app.goldRatesAvailable` is true
  - `_GoldRatesUnavailableBanner`: shown when gold rates are loading or unavailable (spinner vs wifi-off icon)
  - Submit guard: if `computeGoldValue` returns null, shows SnackBar error instead of saving 0
### `add_transaction_screen.dart`
- Gold accounts filtered from `AccountCardPicker`: `app.accounts.where((a) => !a.isGold)`
- Amount field + currency picker + optional conversion preview banner
- Works as both Add and Edit (pass `existing:` to constructor)
### `transactions_screen.dart`
- Search bar with rounded `OutlineInputBorder` (v1.0.5 styling tweak)
- Type filters (All · Income · Expenses · Lent & Borrowed) + per-account filters now use the **themed `_FilterPill`** widget (coloured per item) instead of Material's default `FilterChip`
- Grouped by date with day headers (Today / Yesterday / full date)
- Tap → edit via `ExpensyRoute`; long-press → delete
### `recurring_screen.dart`
- Gold accounts filtered from `AccountCardPicker` in `_RecurringSheet`
- `TabController` (2 tabs): Expenses · Income
- FAB label changes per active tab
- **NEW v1.0.5:** `_RecurringCard` is now a `StatefulWidget` (keyed by `ValueKey(r.id)`) with an expandable **"Payment history"** `ExpansionTile` per card. Expanding it for the first time calls `app.getHistoryFor(r.id)` and renders `_HistoryRow` entries (check icon for Pay, skip icon for Skip, date + amount). `_history` is invalidated (`setState(() => _history = null)`) after a Pay or Skip action so it reloads on next expand.
### `transfer_screen.dart`
- Gold accounts filtered from both FROM and TO pickers
- Cross-currency preview card shows live conversion when currencies differ
### `budget_screen.dart` — **NEW v1.0.5** (bottom-nav tab)
- `BudgetScreen` (`StatelessWidget`): summary strip (`_SumChip` ×2/3 — Budgeted, Spent, and a conditional "Over limit" count chip), then a `ListView` of `_BudgetCard`s
- `_BudgetCard`: category dot + name, period/amount subtitle, spent/remaining pill (colour-coded), progress bar via `_barColor()` (primary < 75%, orange ≥ 75%, error ≥ 100%). Tap → edit sheet; long-press → `showDeleteConfirm` then `deleteBudget`
- `_BudgetSheet`: amount field, Monthly/Weekly period toggle, `CategoryChipPicker` (expense categories only), and a live preview card (spend vs. entered amount + mini progress bar) shown once both an amount and a category are chosen
- FAB → `_openSheet()` (static, callable with `existing:` for edit)
### `more_screen.dart`
- List: Statistics, **Insights**, **Currency Converter**, Wishlist, Lent Money, Assets, Categories, Export, Backup, Settings
- Navigation uses `ExpensyRoute` instead of `MaterialPageRoute`
### `statistics_screen.dart`
- Month navigator, Income/Expense/Net row, 6-month `BarChart`, expense `PieChart`
- **NEW v1.0.5:** `_filterAccountId` state (`null` = all accounts) drives a row of `_FilterPill`s above the month navigator; it filters the month's transactions, the 6-month bar data, **and** the pie-chart breakdown. A `WidgetsBinding.instance.addPostFrameCallback` guard resets the filter to `null` if the selected account was deleted while active.
- **NEW v1.0.5:** Each pie-chart legend row checks `app.budgetForCategory(catId)` — when a budget exists for that category, the row shows "`X% of budget`" plus a thin mini progress bar underneath, colour-matched to the same primary/orange/error thresholds used in `budget_screen.dart`.
### `insights_screen.dart` — **NEW v1.0.5** (More tab)
- `InsightsScreen` (`StatelessWidget`) with static helpers: `_txsInMonth()`, `_converted()` (resolves tx currency → main currency), `_sum()`, `_byCategory()`
- Sections, in order: month-over-month comparison header with `_TrendBadge` (▲/▼ percentage), Daily Average card (this month's expense ÷ days elapsed), Biggest Single Transaction card, Top Spending Categories card (top 3, with share %), Category Trends vs Last Month card (`_buildTrendRows()` — per-category up/down rows), 12-Month Trend `LineChart` (income vs expense)
- Empty state shown when `app.transactions.isEmpty`
### `currency_converter_screen.dart` — **NEW v1.0.5** (More tab)
- `CurrencyConverterScreen` (`StatefulWidget`): `_from` defaults to `settings.currency`, `_to` defaults to `'USD'` unless main currency already is USD (then `'EUR'`)
- Amount field → `_convert()` calls `app.convertBetween(amount, _from, _to)`; `_swap()` flips `_from`/`_to` and reconverts
- Shows a "1 FROM = X TO" unit-rate line and an offline banner when `!app.ratesLoaded || app.exchangeRates.isEmpty`
### `categories_screen.dart`
- Expense + Income sections; add/edit via `_CategorySheet`
- **NEW v1.0.5:** `_CatTile` now renders via `CategoryDot` (icon-aware) instead of a hardcoded label icon
- **NEW v1.0.5:** `_CategorySheet` gained:
  - A live preview chip (icon + name in the category's colour) next to the sheet title
  - **Colour palette expanded from 12 → 40 colours** (`_kCatColors`), grouped into 8 hue families of 5: Purples & violets, Blues, Teals & cyans, Greens, Reds & pinks, Oranges & ambers, Browns & warm neutrals, Slates & grays
  - An **icon picker**: an "Auto" chip (`_iconIndex = 0`, `Icons.auto_awesome_outlined`) plus a 7-column `GridView` over `kCategoryIconOptions`, each cell a `Tooltip`-wrapped `AnimatedContainer`. Selecting a cell sets `_iconIndex = i + 1` (1-based) — **never** construct `IconData` dynamically here
  - `_submit()` now passes `iconCodePoint: _iconIndex` on both `addCategory` and `updateCategory`
### `wishlist_screen.dart`
- Priority: Low (green) / Medium (orange) / High (red); tap circle → toggle purchased
### `lended_screen.dart`
- Gold accounts filtered from `AccountCardPicker` (lend not linked to a gold account)
- `LendedScreen.openSheetFromExternal(ctx, {existing})` — called from `transactions_screen`
- **NEW v1.0.5:** `_LendedCard` shows an **"Overdue!"** badge (red, replacing the normal due-date text) once `dueDate` has passed without the record being settled; also shows a reminder badge (`Icons.notifications_active_outlined` + time) when `reminderEnabled`
- **NEW v1.0.5:** `_LendedSheet` gained a `SwitchListTile` "Due Date Reminder" + time picker, gated on `_dueDate != null` (disabled with a SnackBar prompt if the user tries to enable it without a due date first) and on notification permission (same `hasPermission()`/`requestPermissions()` flow as the recurring sheet). Clearing the due date also force-disables the reminder.
### `assets_screen.dart`
- Summary bar: **Total Assets / Items** *(the "Currency" column shown in pre-1.0.5 builds was removed)*
- Add/edit via `_AssetSheet`
### `export_screen.dart`
- From/To date range → `.xlsx` via `excel` package; includes `Currency` column
- *(Unchanged in v1.0.5)*
### `backup_screen.dart`
- Live counts for **8** categories (Accounts, Transactions, Recurring, Wishlist, Lent & Borrowed, Assets, Categories, Settings)
- Backup format **v9** · JSON (exported data also includes `budgets` and `recurring_history`, but see the **Known gap** callout in §5 — this screen's UI list itself was not updated to show those two)
- `restoreBackup()` returns `int`: 0 = cancelled, ≥1 = success (shows upgrade label if < v9)
- *(Source file unchanged since v1.0.4 — this is the gap referenced above)*
### `settings_screen.dart`
- **CHANGED v1.0.5 — Theme mode:** a row of **3** `_ThemeCard`s (System / Light / Dark) replaces the old 2×2 grid of 4. Cards are taller (`height: 68`) with a vertical icon-over-label layout and an outline border when unselected.
- **NEW v1.0.5 — AMOLED toggle:** a `SwitchListTile` ("Pure Black (AMOLED)") shown directly below the theme row whenever `themeMode != 'light'`; bound to `settings.amoledSurfaces`.
- **NEW v1.0.5 — App Font section:** a `Wrap` of pill chips, one per `kFonts` entry, bound to `settings.appFont`.
- Accent colour: `Wrap` of 29 coloured circles *(unchanged — but only meaningful when Material You isn't overriding the palette; see §8)*
- Currency: tap → `showCurrencyPicker()`
- Week start, Hide balance toggle
- **About section**: Version badge (`v1.0.5`), Privacy row, **GitHub row** → opens `https://github.com/mina-android/Expensy`, **Developer row** → opens `https://github.com/mina-android` via `url_launcher` (`launchUrl` with `LaunchMode.externalApplication`)
### `onboarding_screen.dart`
- 3-step `PageView`: User name → Default currency → First account (bank/cash/savings only — no gold)
- Navigates to `MainShell` via `ExpensyRoute` (was `MaterialPageRoute`)
---
 
## 11. Android Build Config
 
| Item | Value |
|---|---|
| Gradle wrapper | 8.11.1 |
| AGP | 8.9.1 |
| Kotlin | 2.1.0 |
| Java | 11 |
| Package | `com.ma.expensy` |
| `gradle.properties` | `org.gradle.configuration-cache=false`, `kotlin.incremental=false` |
| `coreLibraryDesugaringEnabled` | `true` (required for `flutter_local_notifications` on API < 26) |
| desugar dependency | `com.android.tools:desugar_jdk_libs:2.1.4` |
 
> **Unchanged in v1.0.5** — no Gradle/AGP/Kotlin/manifest changes were needed for any of the new features (Budgets, Insights, Currency Converter, dynamic colour, fonts, lended reminders). The Material You support comes entirely from the `dynamic_color` Dart package; no native Android config was touched.
 
**Notes:**
- Gradle 9.x causes a `BuildOperationDescriptor.metadata()` incompatibility with Kotlin 2.1.0. Keep the Gradle wrapper at 8.11.1.
- AGP must be **≥8.9.1** — `url_launcher_android` pulls in `androidx.browser:1.9.0` and `androidx.core:1.17.0`, which both require AGP 8.9.1. AGP 8.9.1 is fully compatible with Gradle 8.11.1.
- `flutter_timezone` must NOT be used — it fails to compile against Kotlin 2.1.0. Use `DateTime.now().timeZoneOffset` instead.
### AndroidManifest `<queries>` block
Required for Android 11+ package visibility. Includes:
- `android.intent.action.VIEW` + `scheme="content"` — file picker / share
- `android.intent.action.VIEW` + `scheme="https"` — **url_launcher** browser intent
- `android.intent.action.GET_CONTENT` — file picker
- `android.intent.action.SEND` + `mimeType="*/*"` — share
### AndroidManifest Permissions
 
```xml
android.permission.INTERNET                          <!-- Exchange rates + gold price API -->
android.permission.ACCESS_NETWORK_STATE
android.permission.POST_NOTIFICATIONS                <!-- Android 13+ runtime -->
android.permission.SCHEDULE_EXACT_ALARM              <!-- Android 12+ exact alarm -->
android.permission.USE_EXACT_ALARM                   <!-- Android 13+ default grant -->
android.permission.RECEIVE_BOOT_COMPLETED            <!-- Reschedule after reboot -->
android.permission.READ_EXTERNAL_STORAGE  maxSdk=32
android.permission.WRITE_EXTERNAL_STORAGE maxSdk=29
android.permission.READ_MEDIA_IMAGES                 <!-- Android 13+ -->
```
These cover the new `expensy_lended` notification channel too — no new permissions were required for lent/borrowed reminders, they reuse `POST_NOTIFICATIONS` / `SCHEDULE_EXACT_ALARM`.
 
---
 
## 12. Assets (file)
 
```
assets/
└── splash_icon.png   # 3D wallet icon (transparent bg) — shown in launch_background.xml
```
 
---
 
## 13. Notification Icons
 
```
android/app/src/main/res/
├── drawable/
│   └── ic_notification.png          # 24×24 mdpi fallback (full-canvas, ~100% fill)
├── drawable-mdpi/
│   └── ic_notification.png          # 24×24px
├── drawable-hdpi/
│   └── ic_notification.png          # 36×36px
├── drawable-xhdpi/
│   └── ic_notification.png          # 48×48px
├── drawable-xxhdpi/
│   └── ic_notification.png          # 72×72px (~94% fill)
└── drawable-xxxhdpi/
    └── ic_notification.png          # 96×96px (~96% fill)
```
 
- Referenced by `notification_service.dart` as `@drawable/ic_notification` — used by **both** the `expensy_recurring` and `expensy_lended` channels; there is no separate icon per channel.
- Icons are **white on transparent** and fill the canvas edge-to-edge so they render at the correct visual weight in the status bar and notification panel.
- The `<monochrome>` layer in `mipmap-anydpi-v26/ic_launcher.xml` and `ic_launcher_round.xml` uses `@drawable/ic_launcher_monochrome` (separate resource with the correct adaptive-icon inset of ~29% fill). These two resources must **not** be conflated.
---
 
## 14. Backup File Format (v9)
 
```json
{
  "accounts": [ { "id", "name", "type", "balance", "currency",
                  "color_value", "exclude_from_total", "created_at",
                  "gold_karat", "gold_grams" } ],
  "categories":         [ { "id", "name", "type", "color_value",
                            "icon_code_point" } ],
  "transactions":       [ { "id", "type", "amount", "description",
                            "account_id", "category_id", "date", "note", "currency" } ],
  "recurring_payments": [ { "id", "name", "account_id", "category_id", "amount",
                            "payment_type", "freq_val", "freq_unit",
                            "start_date", "next_date", "end_date",
                            "paid_payments", "reminder_enabled", "reminder_time",
                            "early_reminder_enabled", "notes" } ],
  "wishlist":           [ { "id", "name", "target_price", "priority",
                            "is_purchased", "notes", "created_at" } ],
  "lended_money":       [ { "id", "person_name", "amount", "type", "account_id",
                            "is_settled", "date", "due_date", "notes",
                            "reminder_enabled", "reminder_time" } ],
  "assets":             [ { "id", "name", "value", "currency", "notes", "created_at" } ],
  "budgets":            [ { "id", "category_id", "amount", "period", "created_at" } ],
  "recurring_history":  [ { "id", "recurring_id", "action", "date", "amount", "currency" } ],
  "version": 9,
  "settings": { "currency", "themeSeed", "themeMode", "weekStart",
                "hideBalance", "userName", "onboarded",
                "appFont", "amoledSurfaces" }
}
```
 
**Old backup compatibility** — `_normaliseBackup` in `DBHelper` handles every version:
- v1: missing `exclude_from_total`, `payment_type` → filled with defaults
- v2: missing `reminder_time` → defaults to `'09:00'`
- v3: missing `currency` on transactions → defaults to `''`
- v4: missing `assets` key → restored as empty list
- v5: missing `gold_karat`/`gold_grams` on accounts → set to `null`
- v6: missing `early_reminder_enabled` on recurring → defaults to `0`
- v7: missing `budgets` / `recurring_history` keys → restored as empty lists; budget rows missing `period` → `'monthly'`
- v8: missing `icon_code_point` on categories → `0`; missing `reminder_enabled`/`reminder_time` on lended_money → `0` / `'09:00'`
- Settings: `pitch_black` seed → `midnight`; legacy `darkMode: bool` → `themeMode` string; legacy `themeMode: 'amoled'` → `themeMode: 'dark'` + `amoledSurfaces: true`; unknown seed/mode/font → safe defaults
---
 
## 15. Known Conventions & Rules
 
1. **No `withOpacity()`** — always use `.withValues(alpha: x)` (Flutter 3.27+)
2. **No `heroTag` conflicts** — every `FloatingActionButton` has `heroTag: null`
3. **No ambiguous imports** — `AppCategory` not `Category`; `AppTransaction` not `Transaction`
4. **`context.read<AppProvider>()`** in all `_submit()` / async callbacks inside sheets
5. **`context.watch<AppProvider>()`** in `build()` methods only — exception: `_AccountCard` uses `watch` so it rebuilds when exchange rates arrive
6. **Bottom sheets** shown with `showModalBottomSheet(isScrollControlled: true, useSafeArea: true)`
7. **File-level functions** for sheet launchers in screens that need them accessible from multiple widget classes (e.g. `_openRecurringSheet`)
8. **`formatAmount(double, String)`** handles negative values (prepends `-`); always use this for all money display
9. **Dollar signs in Dart strings**: use raw strings or `r'...'` when writing from Python to avoid `\$` escaping corruption
10. **`DropdownButtonFormField`** — use `initialValue:` not `value:` (deprecated after Flutter 3.33)
11. **`main()` is async** — awaits `NotificationService().initialize()` then `provider.load()` before `runApp()`; no `_LoadingScreen` exists; `MaterialApp` is wrapped in `DynamicColorBuilder`
12. **`zonedSchedule` requires `uiLocalNotificationDateInterpretation`** — always pass `UILocalNotificationDateInterpretation.absoluteTime` even on Android-only builds
13. **Do not use `flutter_timezone`** — Kotlin 2.1.0 incompatibility. Use `DateTime.now().timeZoneOffset` to convert local → UTC for `TZDateTime.utc()`
14. **Notification ID stability** — recurring: `paymentId.hashCode & 0x7FFFFFFF`; lended: `'lended_$id'.hashCode & 0x7FFFFFFF`. Do not change either formula or existing scheduled alarms become orphaned
15. **Exchange rate cache** — stored in `SharedPreferences` under keys `er_rates` (JSON, always includes XAU after first successful gold fetch) and `er_fetched_at` (ISO8601); 24-hour TTL. Staleness checks and refresh orchestration live in `AppProvider._loadRates()` (stale-while-revalidate, two `notifyListeners()` calls) — don't move that logic back into `ExchangeRateService.getRates()`
16. **Transaction currency display** — always resolve `t.currency.isNotEmpty ? t.currency : accountById(t.accountId)?.currency` before calling `formatAmount`
17. **Transfer amounts** — `addTransfer` takes `fromAmount` (in FROM account's currency); the provider converts to the TO account's currency. Never pass a single amount and assume it applies to both sides when currencies differ
18. **`restoreBackup()` returns `int`** — `0` = cancelled, `≥1` = source version; throws `FormatException` for invalid files. The backup screen catches `FormatException` separately from generic errors
19. **DB version is 9** — any new schema change must bump `_version`, add an `if (oldV < N)` migration block, and update `_normaliseBackup` if the new column needs a default for old backup rows
20. **Gold accounts** — `isGold` getter on `Account`; always filter with `!a.isGold` before passing to any `AccountCardPicker`. Balance is synthetic (auto-recalculated from XAU rates) — never modify gold account balance via `_updateAccountBalance`. Submit guards must check `computeGoldValue` for null before saving.
21. **`totalBalance` vs `totalBalanceAll`** — home screen uses `totalBalance` (respects `excludeFromTotal`); accounts tab AppBar uses `totalBalanceAll` (all accounts). Never swap these.
22. **url_launcher** — use `canLaunchUrl(uri)` before `launchUrl(uri, mode: LaunchMode.externalApplication)`. The `<queries>` block in `AndroidManifest.xml` must include `scheme="https"` for this to work on Android 11+. Used for both the GitHub (Expensy repo) and Developer (mina-android profile) links in Settings → About.
23. **XAU is not in open.er-api.com free tier** — always fetch gold price separately via `ExchangeRateService.fetchGoldRate()`. Use `goldRatesAvailable` getter (not just `exchangeRates.isNotEmpty`) to gate any gold UI that requires XAU.
24. **Notification icon vs themed icon** — `@drawable/ic_notification` (full-canvas, used by `NotificationService` for both channels) and `@drawable/ic_launcher_monochrome` (29% fill inset, used as `<monochrome>` layer in adaptive icon) are **separate resources**. Never point the adaptive icon's `<monochrome>` at `ic_notification`.
25. **Category icon storage** *(NEW)* — `AppCategory.iconCodePoint` is a **1-based index** into `kCategoryIconOptions`, not a raw `IconData.codePoint`. `0` = Auto/name-heuristic. Never call `IconData(someInt, fontFamily: 'MaterialIcons')` at runtime anywhere in the app — it silently breaks icon tree-shaking in release builds and the icon renders as a missing-glyph box. Always index into the constant list.
26. **AMOLED is independent of theme mode** *(NEW)* — check `settings.amoledSurfaces`, not `settings.themeMode == 'amoled'` (that value no longer exists). AMOLED only has visible effect when the resolved theme is dark; hide the toggle (or make it a no-op) under `themeMode == 'light'`.
27. **Material You only applies under `themeMode == 'system'`** *(NEW)* — pass `dynamicScheme` into `buildTheme()` only when `settings.themeMode == 'system'`; otherwise pass `null` so the chosen accent seed is used. `DynamicColorBuilder` already returns `null` palettes on unsupported devices, so no extra `Platform`/SDK-version check is needed.
28. **`ExpensyRoute` over `MaterialPageRoute`** *(NEW)* — use `ExpensyRoute(builder: (_) => Screen())` for all screen-to-screen pushes so transition timing stays consistent (220ms push / 160ms pop). Don't hand-roll a different transition for new screens.
29. **Budget period boundaries respect `weekStart`** *(NEW)* — when computing a weekly budget's spend window, always derive `periodStart` using `settings.weekStart` (see `budgetSpent()` in §6) rather than assuming Monday.
30. **Recurring history cache invalidation** *(NEW)* — any code path that inserts a `RecurringHistoryEntry` (currently only `markRecurringPaid` / `skipNextRecurring`) must evict `_historyCache[recurringId]` afterward, and any UI showing history must reload via `getHistoryFor()` rather than reusing a previously-fetched list.
31. **Backup screen is behind the backup format** *(known issue, NOT yet fixed)* — `backup_screen.dart`'s live "what's included" counts only cover 8 of the now-9 backed-up tables (no Budgets / Recurring History row), even though both are correctly exported and restored. If picking up backup-related work, consider adding those two rows while you're in there.